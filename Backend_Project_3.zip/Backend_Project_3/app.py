"""DecodeLabs Project 3: Secure Authentication System (Flask + JWT)."""
import os
from datetime import datetime, timedelta, timezone
from functools import wraps

import jwt
from dotenv import load_dotenv
from flask import Flask, g, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError
from werkzeug.security import check_password_hash, generate_password_hash

load_dotenv()
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///users.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', '')
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    def public(self):
        return {'id': self.id, 'name': self.name, 'email': self.email}


class RevokedToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    jti = db.Column(db.String(64), unique=True, nullable=False, index=True)
    expires_at = db.Column(db.DateTime(timezone=True), nullable=False)


def token_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        authorization = request.headers.get('Authorization', '')
        parts = authorization.split()
        if len(parts) != 2 or parts[0].lower() != 'bearer':
            return jsonify(success=False, message='Bearer token is required'), 401
        try:
            payload = jwt.decode(parts[1], app.config['SECRET_KEY'], algorithms=['HS256'], options={'require': ['exp', 'iat', 'sub', 'jti']})
            if db.session.query(RevokedToken.id).filter_by(jti=payload['jti']).first():
                return jsonify(success=False, message='Token has been revoked'), 401
            user = db.session.get(User, int(payload['sub']))
            if user is None:
                return jsonify(success=False, message='User not found'), 401
        except (jwt.InvalidTokenError, ValueError, TypeError):
            return jsonify(success=False, message='Invalid or expired token'), 401
        g.current_user = user
        g.token_payload = payload
        return fn(*args, **kwargs)
    return wrapper


@app.get('/')
def home():
    return jsonify(message='Welcome to Backend Project 3: Secure Authentication System', endpoints=['POST /register', 'POST /login', 'GET /profile', 'POST /logout'])


@app.post('/register')
def register():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(success=False, message='Send a JSON object'), 400
    name = data.get('name')
    email = data.get('email')
    password = data.get('password')
    if not all(isinstance(v, str) for v in [name, email, password]):
        return jsonify(success=False, message='Name, email and password are required'), 400
    name, email = name.strip(), email.strip().lower()
    if not name or len(name) > 100 or not email or len(email) > 255 or '@' not in email or not email.split('@')[-1].count('.'):
        return jsonify(success=False, message='Enter a valid name and email'), 400
    if len(password) < 8 or len(password) > 128:
        return jsonify(success=False, message='Password must be 8–128 characters'), 400
    user = User(name=name, email=email, password_hash=generate_password_hash(password, method='scrypt'))
    db.session.add(user)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify(success=False, message='Email is already registered'), 409
    return jsonify(success=True, message='Registration successful', user=user.public()), 201


@app.post('/login')
def login():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(success=False, message='Send a JSON object'), 400
    email, password = data.get('email'), data.get('password')
    if not isinstance(email, str) or not isinstance(password, str):
        return jsonify(success=False, message='Email and password are required'), 400
    user = db.session.query(User).filter_by(email=email.strip().lower()).first()
    if user is None or not check_password_hash(user.password_hash, password):
        return jsonify(success=False, message='Invalid email or password'), 401
    now = datetime.now(timezone.utc)
    import uuid
    token = jwt.encode({'sub': str(user.id), 'iat': now, 'exp': now + timedelta(hours=1), 'jti': uuid.uuid4().hex}, app.config['SECRET_KEY'], algorithm='HS256')
    return jsonify(success=True, message='Login successful', access_token=token, token_type='Bearer', expires_in=3600), 200


@app.get('/profile')
@token_required
def profile():
    return jsonify(success=True, message='Protected route accessed successfully', user=g.current_user.public())


@app.post('/logout')
@token_required
def logout():
    expires = datetime.fromtimestamp(g.token_payload['exp'], timezone.utc).replace(tzinfo=None)
    db.session.add(RevokedToken(jti=g.token_payload['jti'], expires_at=expires))
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
    return jsonify(success=True, message='Logged out successfully')


if __name__ == '__main__':
    if not app.config['SECRET_KEY']:
        raise RuntimeError('Set JWT_SECRET_KEY in your .env file before starting the server.')
    with app.app_context():
        db.create_all()
    app.run(debug=os.getenv('FLASK_DEBUG', '0') == '1')
