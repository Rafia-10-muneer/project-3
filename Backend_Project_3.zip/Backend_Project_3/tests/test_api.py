import pytest
from app import app, db, User


@pytest.fixture
def client():
    app.config.update(TESTING=True, SECRET_KEY='test-only-secret', SQLALCHEMY_DATABASE_URI='sqlite:///:memory:')
    with app.app_context():
        db.create_all()
        yield app.test_client()
        db.session.remove()
        db.drop_all()


def register(client):
    return client.post('/register', json={'name': 'Sara', 'email': 'sara@example.com', 'password': 'MySecurePass123'})


def login(client, password='MySecurePass123'):
    return client.post('/login', json={'email': 'sara@example.com', 'password': password})


def test_registration_and_hashing(client):
    response = register(client)
    assert response.status_code == 201
    assert 'password' not in response.json['user']
    with app.app_context():
        user = db.session.query(User).filter_by(email='sara@example.com').one()
        assert user.password_hash != 'MySecurePass123'
    assert register(client).status_code == 409


def test_login_and_protected_route(client):
    register(client)
    assert login(client, 'wrong-password').status_code == 401
    token = login(client).json['access_token']
    assert client.get('/profile').status_code == 401
    assert client.get('/profile', headers={'Authorization': 'Bearer garbage'}).status_code == 401
    profile = client.get('/profile', headers={'Authorization': f'Bearer {token}'})
    assert profile.status_code == 200
    assert profile.json['user']['email'] == 'sara@example.com'


def test_logout_revokes_token(client):
    register(client)
    token = login(client).json['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    assert client.post('/logout', headers=headers).status_code == 200
    assert client.get('/profile', headers=headers).status_code == 401


def test_invalid_inputs(client):
    assert client.post('/register', json={'name': 'A', 'email': 'bad', 'password': '12345678'}).status_code == 400
    assert client.post('/register', json={'name': 'A', 'email': 'a@example.com', 'password': 'short'}).status_code == 400
    assert client.post('/login', json={}).status_code == 400
