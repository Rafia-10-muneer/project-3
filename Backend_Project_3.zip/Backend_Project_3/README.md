# Secure Authentication System — Backend Development Project 3

**Internship:** DecodeLabs | **Technology:** Python, Flask, SQLite, JWT | **Project type:** REST API

## Overview

A Flask REST API demonstrating password hashing, JWT authentication, and access control for protected routes. Passwords are hashed using Werkzeug's scrypt; login returns an HS256 JWT valid for one hour. The `/profile` endpoint only works with a valid Bearer token. The additional `/logout` endpoint revokes the current token.

## Features

- User registration with validation and duplicate-email checks
- Secure password hashing (passwords are never stored or returned in plaintext)
- Login with JSON Web Token (JWT)
- Protected profile route with token verification
- Token expiry (1 hour) and logout revocation
- SQLite database, environment-based secret, consistent JSON responses

## Project files

```text
Backend_Project_3/
├── app.py                 # Flask API, database models and authentication
├── requirements.txt       # Python dependencies
├── .env.example           # Safe example of environment variables
├── .gitignore             # Prevent secrets and databases from being committed
├── postman_collection.json # Importable Postman requests
├── tests/                 # Automated API tests
└── README.md              # Setup, usage and testing guide
```

## Requirements

- Python 3.10+ (use a version supported by the dependencies)
- VS Code or another code editor
- Postman (optional; useful for manual API testing)

## Setup (Windows PowerShell)

1. Open the extracted `Backend_Project_3` folder in VS Code and open **Terminal → New Terminal**.
2. Create and activate a virtual environment:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use `.venv\Scripts\python.exe` instead of `python` in the following commands (no activation needed).

3. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

4. Create a `.env` file by copying `.env.example`:

   ```powershell
   Copy-Item .env.example .env
   ```

   Generate a random secret:

   ```powershell
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

   Paste the generated value after `JWT_SECRET_KEY=` in `.env`. **Never commit `.env` to GitHub.**

5. Start the server:

   ```powershell
   python app.py
   ```

   Open `http://127.0.0.1:5000/` in your browser. SQLite tables are created automatically on startup in Flask's `instance` directory.

## API endpoints

| Method | Endpoint | Authentication | Description |
|---|---|---|---|
| GET | `/` | No | API welcome message |
| POST | `/register` | No | Register a new user |
| POST | `/login` | No | Log in and receive a JWT |
| GET | `/profile` | Bearer token | Get the logged-in user's profile |
| POST | `/logout` | Bearer token | Revoke the current JWT |

### 1. Register

**POST** `http://127.0.0.1:5000/register`  
Postman: **Body → raw → JSON**

```json
{
  "name": "Sara",
  "email": "sara@example.com",
  "password": "MySecurePass123"
}
```

Expected: **201 Created**, user details (no password). Duplicate email returns **409**.

### 2. Login

**POST** `http://127.0.0.1:5000/login`  
Postman: **Body → raw → JSON**

```json
{
  "email": "sara@example.com",
  "password": "MySecurePass123"
}
```

Expected: **200 OK** with `access_token`, `token_type: "Bearer"`, and `expires_in: 3600`. Copy the actual token from your response.

### 3. Access protected profile

**GET** `http://127.0.0.1:5000/profile`  
Postman: **Authorization → Bearer Token → paste access_token** (or header `Authorization: Bearer YOUR_TOKEN`).

Expected: **200 OK** with your user details. No token, invalid token, revoked token, or expired token returns **401 Unauthorized**.

### 4. Logout (additional feature)

**POST** `http://127.0.0.1:5000/logout`  
Use the same Bearer token. Expected: **200 OK**. Using the same token again on `/profile` returns **401**.

## Import into Postman

1. Open Postman → **Import** → choose `postman_collection.json`.
2. The collection has a `base_url` variable set to `http://127.0.0.1:5000`.
3. Send **Register**, then **Login**. The Login test script saves `access_token` automatically in the collection variables.
4. Send **Protected Profile**; the saved token is used automatically. Then send **Logout** and try **Protected Profile** again to confirm access is denied.

## Run automated tests

Install test dependency:

```powershell
python -m pip install pytest
python -m pytest -q
```

Tests use a temporary in-memory SQLite database and a test-only secret. They cover registration, login, password hashing, protected routes, token errors, and logout.

## GitHub submission

Upload `app.py`, `requirements.txt`, `.env.example`, `.gitignore`, `postman_collection.json`, `tests/`, and `README.md` to your Project 3 repository. **Do not upload `.env`, `.venv`, or database files.** Suggested repository description: `Secure Flask authentication API with password hashing, JWT login and protected routes — DecodeLabs Backend Project 3.`

## Security notes

This is an educational internship project. For production deployment, use HTTPS, rate limiting for login, stricter email validation, token-revocation cleanup, database migrations, secret rotation, and proper monitoring. Keep debug mode off on public servers. JWT payloads are signed, not encrypted; do not store sensitive data in them.
